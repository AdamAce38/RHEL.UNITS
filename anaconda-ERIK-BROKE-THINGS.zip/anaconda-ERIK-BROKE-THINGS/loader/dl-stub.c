void _dl_mcount_wrapper (void *selfpc)
{
}

void _dl_mcount_wrapper_check (void *selfpc)
{
}
