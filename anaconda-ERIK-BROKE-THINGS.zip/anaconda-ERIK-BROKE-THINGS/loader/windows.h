#ifndef _WINDOWS_H_
#define _WINDOWS_H_

void winStatus(int width, int height, char * title, char * text, ...);
void scsiWindow(char * driver);

#endif /* _WINDOWS_H_ */
