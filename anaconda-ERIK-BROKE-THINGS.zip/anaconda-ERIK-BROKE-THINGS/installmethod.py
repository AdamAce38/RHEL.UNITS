class InstallMethod:

    def writeCleanupPath(self, f):
	pass

    def protectedPartitions(self):
        return None

    def readComps(self, hdlist):
	pass

    def getFilename(self, h):
	pass

    def readHeaders(self):
	pass

    def systemUnmounted(self):
	pass

    def systemMounted(self, fstab, mntPoint, selected):
	pass

    def filesDone(self):
	pass

    def unlinkFilename(self, fullName):
	pass

    def __init__(self):
	pass
