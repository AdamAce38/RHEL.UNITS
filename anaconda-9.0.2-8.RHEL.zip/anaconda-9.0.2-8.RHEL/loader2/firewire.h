#ifndef H_FIREWIRE
#define H_FIREWIRE

int firewireInitialize(moduleList modLoaded, moduleDeps modDeps,
		       moduleInfoSet modInfo, int flags);

#endif
