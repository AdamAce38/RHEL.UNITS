#
# desktop_choice_text.py: choose desktop
#
# Copyright 2002 Red Hat, Inc.
#
# This software may be freely redistributed under the terms of the GNU
# library public license.
#
# You should have received a copy of the GNU Library Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
#

from snack import *
from constants_text import *
from rhpl.translate import _
from constants import productName

class DesktopChoiceWindow:
    def __call__(self, screen, intf, instclass, dispatch):

	bb = ButtonBar (screen, (TEXT_OK_BUTTON, TEXT_BACK_BUTTON))
	
	toplevel = GridFormHelp (screen, _("Workstation Defaults"),
				 "wsdefaults", 1, 5)
	
	labeltxt = N_("The Personal Desktop and Workstation options "
		      "install a default set of applications that will "
		      "allow you to browse the Internet, send and receive "
		      "email, and create and edit documents on your %s "
		      "system. The Workstation option includes development "
		      "and administration tools as well.\n\n"
		      "However %s ships with many more applications, and "
		      "you may customize the selection of software "
		      "installed if you want.")
			  
	toplevel.add (TextboxReflowed(55, _(labeltxt) % (productName, productName)), 0, 0, (0, 0, 0, 1))
	custom = not dispatch.stepInSkipList("package-selection")
	customize = Checkbox (_("Customize software selection"), custom)
	toplevel.add (customize, 0, 3, (0, 0, 0, 1))	 
	toplevel.add (bb, 0, 4, (0, 0, 0, 0), growx = 1)

	result = toplevel.run()
        rc = bb.buttonPressed (result)
	if rc == TEXT_BACK_CHECK:
	    screen.popWindow()
	    return INSTALL_BACK

	if customize.selected():
	    dispatch.skipStep("package-selection", skip = 0)
	else:
	    dispatch.skipStep("package-selection")
	    
	screen.popWindow()
				 
        return INSTALL_OK

