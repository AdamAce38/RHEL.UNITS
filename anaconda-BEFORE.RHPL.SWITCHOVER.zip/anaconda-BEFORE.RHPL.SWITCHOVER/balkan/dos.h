#ifndef H_DOS
#define H_DOS 1

int dospReadTable(int fd, struct partitionTable * table);

#endif;
