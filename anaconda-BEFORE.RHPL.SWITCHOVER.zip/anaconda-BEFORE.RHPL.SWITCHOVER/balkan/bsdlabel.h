#ifndef H_DOS
#define H_DOS 1

int bsdlReadTable(int fd, struct partitionTable * table);

#endif;
