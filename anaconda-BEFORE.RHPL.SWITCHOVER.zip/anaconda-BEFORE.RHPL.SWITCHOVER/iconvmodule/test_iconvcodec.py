import iconvcodec

print u"Hallo".encode("T.61")
print repr(unicode("Hallo","T.61"))
