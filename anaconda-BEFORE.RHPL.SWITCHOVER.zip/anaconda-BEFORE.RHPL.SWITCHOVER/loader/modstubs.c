#include <stdlib.h>

int insmod_main(int argc, char ** argv) {
    return 0;
}

int rmmod_main(int argc, char ** argv) {
    return 0;
}
