void _dl_mcount_wrapper (void *selfpc)
{
}

void _dl_mcount_wrapper_check (void *selfpc)
{
}

int _dl_osversion;
int __libc_multiple_libcs;
int __libc_enable_secure;

void __libc_check_standard_fds (void) { }

