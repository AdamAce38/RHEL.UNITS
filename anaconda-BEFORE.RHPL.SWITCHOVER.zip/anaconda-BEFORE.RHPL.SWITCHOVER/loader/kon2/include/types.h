typedef unsigned short u_short;
typedef unsigned char u_char;
typedef unsigned int u_int;
