#define VERSION "ver.0.3.9 (2000/03/21)"
