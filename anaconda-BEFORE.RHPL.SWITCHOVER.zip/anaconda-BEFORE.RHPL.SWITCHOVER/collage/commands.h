#ifndef H_MOUNT
#define H_MOUNT

int mknodCommand(int argc, char ** argv);
int mountCommand(int argc, char ** argv);
int umountCommand(int argc, char ** argv);
int uncpioCommand(int argc, char ** argv);

#endif
