int isysLoadFont(char * fontFile);
int isysLoadKeymap(char * keymap);
