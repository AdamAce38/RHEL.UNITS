#ifndef SMP_H
#define SMP_H

int detectSMP(void);
int detectHT(void);

#endif /* SMP_H */
