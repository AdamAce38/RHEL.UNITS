#
# packages.py: package management - mainly package installation
#
# Erik Troan <ewt@redhat.com>
# Matt Wilson <msw@redhat.com>
# Michael Fulbright <msf@redhat.com>
# Jeremy Katzj <katzj@redhat.com>
#
# Copyright 2001-2003 Red Hat, Inc.
#
# This software may be freely redistributed under the terms of the GNU
# library public license.
#
# You should have received a copy of the GNU Library Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
#

import iutil
import isys
import rpm
import os
import timer
import time
import sys
import string
import pcmcia
import language
import fsset
import kudzu
from flags import flags
from product import *
from constants import *
from syslogd import syslog
from comps import PKGTYPE_MANDATORY, PKGTYPE_DEFAULT
from installmethod import FileCopyException

from rhpl.log import log
from rhpl.translate import _

def queryUpgradeContinue(intf, dir):
    if dir == DISPATCH_FORWARD:
        return

    rc = intf.messageWindow(_("Proceed with upgrade?"),
                       _("The file systems of the Linux installation "
                         "you have chosen to upgrade have already been "
                         "mounted. You cannot go back past this point. "
                         "\n\n") + 
                     _( "Would you like to continue with the upgrade?"),
                                      type = "yesno")
    if rc == 0:
        sys.exit(0)
    return DISPATCH_FORWARD

def doPostAction(id, instPath):
    id.instClass.postAction(instPath, flags.serial)

def firstbootConfiguration(id, instPath):
    if id.firstboot == FIRSTBOOT_RECONFIG:
        f = open(instPath + '/etc/reconfigSys', 'w+')
        f.close()
    elif id.firstboot == FIRSTBOOT_SKIP:
        f = open(instPath + '/etc/sysconfig/firstboot', 'w+')
        f.write('RUN_FIRSTBOOT=NO')
        f.close()

    return
        

def writeConfiguration(id, instPath):
    log("Writing main configuration")
    if not flags.test:
        id.write(instPath)

def writeKSConfiguration(id, instPath):
    log("Writing autokickstart file")
    if not flags.test:
	fn = instPath + "/root/anaconda-ks.cfg"
    else:
	fn = "/tmp/anaconda-ks.cfg"

    id.writeKS(fn)

def writeXConfiguration(id, instPath):
    testmode = flags.test

# comment out to test
    if testmode:
        return
# end code to comment to test 
# uncomment to test writing X config in test mode
#    try:
#	os.mkdir("/tmp/etc")
#    except:
#	pass
#    try:
#	os.mkdir("/tmp/etc/X11")
#    except:
#	pass
#    instPath = '/'
# end code for test writing

    if id.xsetup.skipx:
        return

    xserver = id.videocard.primaryCard().getXServer()
    if not xserver:
	return

    log("Writing X configuration")
    if not testmode:
        fn = instPath

        if os.access (instPath + "/etc/X11/X", os.R_OK):
            os.rename (instPath + "/etc/X11/X",
                       instPath + "/etc/X11/X.rpmsave")

        try:
            os.unlink (instPath + "/etc/X11/X")
        except OSError:
            pass
            
        os.symlink ("../../usr/X11R6/bin/" + xserver,
			    instPath + "/etc/X11/X")
    else:
        fn = "/tmp/"

    id.xsetup.write(fn+"/etc/X11", id.mouse, id.keyboard)
    id.desktop.write(instPath)

def readPackages(intf, method, id):
    while id.hdList is None:
	w = intf.waitWindow(_("Reading"), _("Reading package information..."))
        try:
            id.hdList = method.readHeaders()
        except FileCopyException:
            w.pop()
            method.unmountCD()
            intf.messageWindow(_("Error"),
                               _("Unable to read header list.  This may be "
                                 "due to a missing file or bad media.  "
                                 "Press <return> to try again."))
            continue

        w.pop()
        id.instClass.setPackageSelection(id.hdList, intf)

    while id.comps is None:
        try:
            id.comps = method.readComps(id.hdList)
        except FileCopyException:
            method.unmountCD()            
            intf.messageWindow(_("Error"),
                               _("Unable to read comps file.  This may be "
                                 "due to a missing file or bad media.  "
                                 "Press <return> to try again."))
            continue
        id.instClass.setGroupSelection(id.comps, intf)

    else:
	# re-evaluate all the expressions for packages with qualifiers.

	id.comps.updateSelections()

def handleX11Packages(dir, intf, disp, id, instPath):

    if dir == DISPATCH_BACK:
        return
        
    # skip X setup if it is not being installed
    if (not id.comps.packages.has_key('XFree86') or
        not id.comps.packages['XFree86'].selected):
        disp.skipStep("videocard")
        disp.skipStep("monitor")
        disp.skipStep("xcustom")
        disp.skipStep("writexconfig")
        id.xsetup.skipx = 1
    elif disp.stepInSkipList("videocard"):
        # if X is being installed, but videocard step skipped
        # need to turn it back on
        disp.skipStep("videocard", skip=0)
        disp.skipStep("monitor", skip=0)
        disp.skipStep("xcustom", skip=0)
        disp.skipStep("writexconfig", skip=0)
        id.xsetup.skipx = 0

    # set default runlevel based on packages
    gnomeSelected = (id.comps.packages.has_key('gnome-session')
                     and id.comps.packages['gnome-session'].selected)
    kdeSelected = (id.comps.packages.has_key('kdebase')
                   and id.comps.packages['kdebase'].selected)

    if gnomeSelected:
        id.desktop.setDefaultDesktop("GNOME")
    elif kdeSelected:
        id.desktop.setDefaultDesktop("KDE")

    if gnomeSelected or kdeSelected:
        id.desktop.setDefaultRunLevel(5)

def checksig(fileName):
    # RPM spews to stdout/stderr.  Redirect.
    # stolen from up2date/up2date.py
    saveStdout = os.dup(1)
    saveStderr = os.dup(2)
    redirStdout = os.open("/dev/null", os.O_WRONLY | os.O_APPEND)
    redirStderr = os.open("/dev/null", os.O_WRONLY | os.O_APPEND)
    os.dup2(redirStdout, 1)
    os.dup2(redirStderr, 2)
    # now do the rpm thing
    ret = rpm.checksig(fileName, rpm.CHECKSIG_MD5)
    # restore normal stdout and stderr
    os.dup2(saveStdout, 1)
    os.dup2(saveStderr, 2)
    # Clean up
    os.close(redirStdout)
    os.close(redirStderr)
    os.close(saveStdout)
    os.close(saveStderr)
    return ret    

def checkDependencies(dir, intf, disp, id, instPath):
    if dir == DISPATCH_BACK:
	return

    win = intf.waitWindow(_("Dependency Check"),
      _("Checking dependencies in packages selected for installation..."))

    id.dependencies = id.comps.verifyDeps(instPath, id.upgrade.get())

    win.pop()

    if (id.dependencies and id.comps.canResolveDeps(id.dependencies)
        and id.handleDeps == CHECK_DEPS):
	disp.skipStep("dependencies", skip = 0)
    else:
	disp.skipStep("dependencies")

    # this is kind of hackish, but makes kickstart happy
    if id.handleDeps == CHECK_DEPS:
        pass
    elif id.handleDeps == IGNORE_DEPS:
        id.comps.selectDepCause(id.dependencies)
        id.comps.unselectDeps(id.dependencies)
    elif id.handleDeps == RESOLVE_DEPS:
        id.comps.selectDepCause(id.dependencies)        
        id.comps.selectDeps(id.dependencies)

#XXX
#try:
    #self.todo.getHeaderList ()
    #self.todo.getCompsList()
    #self.files_found = "TRUE"
#except ValueError, msg:
    #extra = msg
#except RuntimeError, msg:
    #extra = msg
#except TypeError, msg:
    #extra = msg
#except KeyError, key:
    #extra = ("The comps file references a package called \"%s\" which "
	     #"could not be found." % (key,))
#except:
    #extra = ""
#
#if self.files_found == "FALSE":
    #if extra:
	#text = (_("The following error occurred while "
		  #"retreiving hdlist file:\n\n"
		  #"%s\n\n"
		  #"Installer will exit now.") % extra)
    #else:
	#text = (_("An error has occurred while retreiving the hdlist "
		  #"file.  The installation media or image is "
		  #"probably corrupt.  Installer will exit now."))
    #win = ErrorWindow (text)
#else:

class InstallCallback:
    def cb(self, what, amount, total, h, (param)):
	# first time here means we should pop the window telling
	# user to wait until we get here
	if not self.beenCalled:
	    self.beenCalled = 1
	    self.initWindow.pop()

	if (what == rpm.RPMCALLBACK_TRANS_START):
	    # step 6 is the bulk of the transaction set
	    # processing time
	    if amount == 6:
		self.progressWindow = \
		   self.progressWindowClass (_("Processing"),
					     _("Preparing to install..."),
					     total)
	if (what == rpm.RPMCALLBACK_TRANS_PROGRESS):
	    if self.progressWindow:
		self.progressWindow.set (amount)
		
	if (what == rpm.RPMCALLBACK_TRANS_STOP and self.progressWindow):
	    self.progressWindow.pop ()

	if (what == rpm.RPMCALLBACK_INST_OPEN_FILE):
	    # We don't want to start the timer until we get to the first
	    # file.
	    self.pkgTimer.start()

	    self.progress.setPackage(h)
	    self.progress.setPackageScale(0, 1)
	    self.instLog.write (self.modeText % (h[rpm.RPMTAG_NAME],
                                                 h[rpm.RPMTAG_VERSION],
                                                 h[rpm.RPMTAG_RELEASE]))
	    self.instLog.flush ()

	    self.rpmFD = -1
            self.size = h[rpm.RPMTAG_SIZE]

	    while self.rpmFD < 0:
		try:
                    fn = self.method.getFilename(h, self.pkgTimer)
		    self.rpmFD = os.open(fn, os.O_RDONLY)

                    # Make sure this package seems valid
                    try:
                        hdr = self.ts.hdrFromFdno(self.rpmFD)
                        os.lseek(self.rpmFD, 0, 0)
                    
                        # if we don't have a valid package, throw an error
                        if not hdr:
                            raise SystemError

		    except:
			try:
			    os.close(self.rpmFD)
			except:
			    pass
			self.rpmFD = -1
			raise FileCopyException
		except:
                    self.method.unmountCD()
		    self.messageWindow(_("Error"),
			_("The package %s-%s-%s cannot be opened. This is due "
                          "to a missing file or perhaps a corrupt package.  "
                          "If you are installing from CD media this usually "
			  "means the CD media is corrupt, or the CD drive is "
			  "unable to read the media.\n\n"
			  "Press <return> to try again.") % (h['name'],
                                                             h['version'],
                                                             h['release']))

	    fn = self.method.unlinkFilename(fn)
	    return self.rpmFD
	elif (what == rpm.RPMCALLBACK_INST_PROGRESS):
	    # RPM returns strange values sometimes
            if amount > total:
                amount = total
            if not total:
                total = amount
            self.progress.setPackageScale(amount, total)
	elif (what == rpm.RPMCALLBACK_INST_CLOSE_FILE):
	    os.close (self.rpmFD)
	    self.progress.completePackage(h, self.pkgTimer)
	    self.progress.processEvents()
        elif ((what == rpm.RPMCALLBACK_UNPACK_ERROR) or
              (what == rpm.RPMCALLBACK_CPIO_ERROR)):
            # we may want to make this error more fine-grained at some
            # point
            pkg = "%s-%s-%s" % (h[rpm.RPMTAG_NAME],
                                h[rpm.RPMTAG_VERSION],
                                h[rpm.RPMTAG_RELEASE])
            self.messageWindow(_("Error Installing Package"),
                               _("There was an error installing %s.  This "
                                 "can indicate media failure, lack of disk "
                                 "space, and/or hardware problems.  This is "
                                 "a fatal error and your install will be "
                                 "aborted.  Please verify your media and try "
                                 "your install again.\n\n"
                                 "Press the OK button to reboot "
                                 "your system.") % (pkg,))
            sys.exit(0)
	else:
	    pass

	self.progress.processEvents()

    def __init__(self, messageWindow, progress, pkgTimer, method,
		 progressWindowClass, instLog, modeText, ts):
	self.messageWindow = messageWindow
	self.progress = progress
	self.pkgTimer = pkgTimer
	self.method = method
	self.progressWindowClass = progressWindowClass
	self.progressWindow = None
	self.instLog = instLog
	self.modeText = modeText
	self.beenCalled = 0
	self.initWindow = None
        self.ts = ts

def sortPackages(first, second):
    # install packages in cd order (cd tag is 1000002)
    one = None
    two = None

    if first[1000003] != None:
	one = first[1000003]

    if second[1000003] != None:
	two = second[1000003]

    if one == None or two == None:
	one = 0
	two = 0
	if first[1000002] != None:
	    one = first[1000002]

	if second[1000002] != None:
	    two = second[1000002]

    if one < two:
	return -1
    elif one > two:
	return 1
    elif (string.lower(first[rpm.RPMTAG_NAME])
          < string.lower(second[rpm.RPMTAG_NAME])):
	return -1
    elif (string.lower(first[rpm.RPMTAG_NAME])
          > string.lower(second[rpm.RPMTAG_NAME])):
	return 1

    return 0

class rpmErrorClass:

    def cb(self):
	self.f.write (rpm.errorString () + "\n")

    def __init__(self, f):
	self.f = f

def doMigrateFilesystems(dir, thefsset, diskset, upgrade, instPath):
    if dir == DISPATCH_BACK:
        return DISPATCH_NOOP

    if thefsset.haveMigratedFilesystems():
        return DISPATCH_NOOP
    
    thefsset.migrateFilesystems (instPath)
    

def turnOnFilesystems(dir, thefsset, diskset, partitions, upgrade, instPath):
    if dir == DISPATCH_BACK:
        log("unmounting filesystems")
	thefsset.umountFilesystems(instPath)
	return

    if flags.setupFilesystems:
	if not upgrade.get():
            partitions.doMetaDeletes(diskset)
            thefsset.setActive(diskset)
            if not thefsset.isActive():
                diskset.savePartitions ()
            thefsset.checkBadblocks(instPath)
            thefsset.createLogicalVolumes(instPath)
            thefsset.formatSwap(instPath)
            thefsset.turnOnSwap(instPath)
	    thefsset.makeFilesystems (instPath)
            log("mounting filesystems")
            thefsset.mountFilesystems (instPath)

def setupTimezone(timezone, upgrade, instPath, dir):
    # we don't need this on an upgrade or going backwards
    if upgrade.get() or (dir == DISPATCH_BACK):
        return
    
    os.environ["TZ"] = timezone.tz
    tzfile = "/usr/share/zoneinfo/" + timezone.tz
    if not os.access(tzfile, os.R_OK):
        log("unable to set timezone")
    else:
        try:
            iutil.copyFile(tzfile, "/etc/localtime")
        except OSError, (errno, msg):
            log("Error copying timezone (from %s): %s" %(tzfile, msg))

    if iutil.getArch() == "s390":
        return
    args = [ "/usr/sbin/hwclock", "--hctosys" ]
    if timezone.utc:
        args.append("-u")
    elif timezone.arc:
        args.append("-a")

    try:
        iutil.execWithRedirect(args[0], args, stdin = None,
                               stdout = "/dev/tty5", stderr = "/dev/tty5")
    except RuntimeError:
        log("Failed to set clock")
    
            

def doPreInstall(method, id, intf, instPath, dir):
    if dir == DISPATCH_BACK:
        return

    arch = iutil.getArch ()

    # this is a crappy hack, but I don't want bug reports from these people
    if (arch == "i386") and (not id.hdList.has_key("kernel")):
        intf.messageWindow(_("Error"),
                           _("You are trying to install on a machine "
                             "which isn't supported by this release of "
                             "%s.") %(productName,),
                           type="custom", custom_icon="error",
                           custom_buttons=[_("_Exit")])
        sys.exit(0)

    # shorthand
    upgrade = id.upgrade.get()

    def select(hdList, name):
        if hdList.has_key(name):
            hdList[name].selected = 1

    if not upgrade:
	# this is NICE and LATE. It lets kickstart/server/workstation
	# installs detect this properly
        if arch == "s390":
	    if (string.find(os.uname()[2], "tape") > -1):
		select(id.hdList, 'kernel-tape')
        elif arch == "ppc" and iutil.getPPCMachine() == "pSeries":
            select(id.hdList, 'kernel-pseries')
        elif arch == "ppc" and iutil.getPPCMachine() == "iSeries":
            select(id.hdList, "kernel-iseries")
                
	if isys.smpAvailable() or isys.htavailable():
            select(id.hdList, 'kernel-smp')

	if (id.hdList.has_key('kernel-bigmem')):
	    if iutil.needsEnterpriseKernel():
		id.hdList['kernel-bigmem'].selected = 1

	if (id.hdList.has_key('kernel-summit')):
	    if isys.summitavailable():
		id.hdList['kernel-summit'].selected = 1

	# we *always* need a kernel installed
        select(id.hdList, 'kernel')

	# if NIS is configured, install ypbind and dependencies:
	if id.auth.useNIS:
            select(id.hdList, 'ypbind')
            select(id.hdList, 'yp-tools')
            select(id.hdList, 'portmap')

	if id.auth.useLdap:
            select(id.hdList, 'nss_ldap')
            select(id.hdList, 'openldap')
            select(id.hdList, 'perl')

	if id.auth.useKrb5:
            select(id.hdList, 'pam_krb5')
            select(id.hdList, 'krb5-workstation')
            select(id.hdList, 'krbafs')
            select(id.hdList, 'krb5-libs')

        if id.auth.useSamba:
            select(id.hdList, 'pam_smb')

        if iutil.getArch() == "i386" and id.bootloader.useGrubVal == 0:
            select(id.hdList, 'lilo')
        elif iutil.getArch() == "i386" and id.bootloader.useGrubVal == 1:
            select(id.hdList, 'grub')
        elif iutil.getArch() == "s390":
            select(id.hdList, 's390utils')
        elif iutil.getArch() == "ppc":
            select(id.hdList, 'yaboot')
        elif iutil.getArch() == "ia64":
            select(id.hdList, 'elilo')

        if pcmcia.pcicType():
            select(id.hdList, 'kernel-pcmcia-cs')

    if flags.test:
	return

    # make sure that all comps that include other comps are
    # selected (i.e. - recurse down the selected comps and turn
    # on the children
    while 1:
        try:
            method.mergeFullHeaders(id.hdList)
        except FileCopyException:
            method.unmountCD()
            intf.messageWindow(_("Error"),
                               _("Unable to merge header list.  This may be "
                                 "due to a missing file or bad media.  "
                                 "Press <return> to try again."))
        else:
            break

    if upgrade:
	# An old mtab can cause confusion (esp if loop devices are
	# in it)
	f = open(instPath + "/etc/mtab", "w+")
	f.close()

    if method.systemMounted (id.fsset, instPath, id.hdList.selected()):
	id.fsset.umountFilesystems(instPath)
	return DISPATCH_BACK

    for i in ( '/var', '/var/lib', '/var/lib/rpm', '/tmp', '/dev', '/etc',
	       '/etc/sysconfig', '/etc/sysconfig/network-scripts',
	       '/etc/X11', '/root', '/var/tmp' ):
	try:
	    os.mkdir(instPath + i)
	except os.error, (errno, msg):
            pass
#            log("Error making directory %s: %s" % (i, msg))


    if flags.setupFilesystems:
	try:
            # FIXME: making the /var/lib/rpm symlink here is a hack to
            # workaround db->close() errors from rpm
            iutil.mkdirChain("/var/lib")
            for path in ("/var/tmp", "/var/lib/rpm"):
                if os.path.exists(path) and not os.path.islink(path):
                    iutil.rmrf(path)
                if not os.path.islink(path):
                    os.symlink("/mnt/sysimage/%s" %(path,), "%s" %(path,))
                else:
                    log("%s already exists as a symlink to %s" %(path, os.readlink(path),))
	except Exception, e:
	    # how this could happen isn't entirely clear; log it in case
	    # it does and causes problems later
	    log("error creating symlink, continuing anyway: %s" %(e,))

    # try to copy the comps package.  if it doesn't work, don't worry about it
    try:
        id.compspkg = method.copyFileToTemp("RedHat/base/comps.rpm")
    except:
        log("Unable to copy comps package")
        id.compspkg = None

    # write out the fstab
    if not upgrade:
        id.fsset.write(instPath)
        # rootpath mode doesn't have this file around
        if os.access("/tmp/modules.conf", os.R_OK):
            iutil.copyFile("/tmp/modules.conf", 
                           instPath + "/etc/modules.conf")

    # make a /etc/mtab so mkinitrd can handle certain hw (usb) correctly
    f = open(instPath + "/etc/mtab", "w+")
    f.write(id.fsset.mtab())
    f.close()
     
#    delay writing migrate adjusted fstab till later, in case
#    rpm transaction set determines they don't have enough space to upgrade
#    else:
#        id.fsset.migratewrite(instPath)

def doInstall(method, id, intf, instPath):
    if flags.test:
	return

    # set up dependency white outs
    import whiteout
    
    upgrade = id.upgrade.get()
    ts = rpm.TransactionSet(instPath)

    ts.setVSFlags(~(rpm.RPMVSF_NORSA|rpm.RPMVSF_NODSA))
    ts.setFlags(rpm.RPMTRANS_FLAG_ANACONDA)

    total = 0
    totalSize = 0

    if upgrade:
	how = "u"
    else:
	how = "i"

    l = []

    for p in id.hdList.selected():
	l.append(p)
    l.sort(sortPackages)

    progress = intf.progressWindow(_("Processing"),
                                   _("Preparing RPM transaction..."),
                                   len(l))


    # this is kind of a hack, but has to be done so we can have a chance
    # with broken triggers
    if upgrade and len(id.upgradeRemove) > 0:
        # simple rpm callback since erasure doesn't need anything
        def install_callback(what, bytes, total, h, user):
            pass

        for pkg in id.upgradeRemove:
            ts.addErase(pkg)

        # if we hit problems, it's not like there's anything we can
        # do about it
        ts.run(install_callback, 0)

        # new transaction set
        ts.closeDB()
        del ts
        ts = rpm.TransactionSet(instPath)
        ts.setVSFlags(~(rpm.RPMVSF_NORSA|rpm.RPMVSF_NODSA))
        ts.setFlags(rpm.RPMTRANS_FLAG_ANACONDA)

        # we don't want to try to remove things more than once (#84221)
        id.upgradeRemove = []

    i = 0
    for p in l:
	ts.addInstall(p.h, p.h, how)
	total = total + 1
	totalSize = totalSize + (p[rpm.RPMTAG_SIZE] / 1024)
        i = i + 1
        progress.set(i)

    progress.pop()
    
    if not id.hdList.preordered():
	log ("WARNING: not all packages in hdlist had order tag")
        # have to call ts.check before ts.order() to set up the alIndex
        ts.check()
        ts.order()

    if upgrade:
	logname = '/root/upgrade.log'
    else:
	logname = '/root/install.log'

    instLogName = instPath + logname
    try:
	iutil.rmrf (instLogName)
    except OSError:
	pass

    instLog = open(instLogName, "w+")
    syslogname = "%s%s.syslog" % (instPath, logname)
    try:
        iutil.rmrf (syslogname)
    except OSError:
        pass
    syslog.start (instPath, syslogname)

    if id.compspkg is not None:
        num = i + 1
    else:
        num = i

    if upgrade:
        instLog.write(_("Upgrading %s packages\n\n") % (num,))
    else:
        instLog.write(_("Installing %s packages\n\n") % (num,))

    ts.scriptFd = instLog.fileno ()
    rpm.setLogFile(instLog)
    # the transaction set dup()s the file descriptor and will close the
    # dup'd when we go out of scope

    if upgrade:
	modeText = _("Upgrading %s-%s-%s.\n")
    else:
	modeText = _("Installing %s-%s-%s.\n")

    errors = rpmErrorClass(instLog)
    pkgTimer = timer.Timer(start = 0)

    id.instProgress.setSizes(total, totalSize)
    id.instProgress.processEvents()

    cb = InstallCallback(intf.messageWindow, id.instProgress, pkgTimer,
			 method, intf.progressWindow, instLog, modeText,
                         ts)

    # write out migrate adjusted fstab so kernel RPM can get initrd right
    if upgrade:
        id.fsset.migratewrite(instPath)
    if id.upgradeDeps:
        instLog.write(_("\n\nThe following packages were automatically\n"
                        "selected to be installed:"
                        "\n"
                        "%s"
                        "\n\n") % (id.upgradeDeps,))
        
    cb.initWindow = intf.waitWindow(_("Install Starting"),
				    _("Starting install process, this may take several minutes..."))

    ts.setProbFilter(~rpm.RPMPROB_FILTER_DISKSPACE)
    problems = ts.run(cb.cb, 0)

    if problems:
        # restore old fstab if we did anything for migrating
        if upgrade:
            id.fsset.restoreMigratedFstab(instPath)

	spaceneeded = {}
	nodeneeded = {}
	size = 12

	# XXX
	nodeprob = -1
	if rpm.__dict__.has_key ("RPMPROB_DISKNODES"):
	    nodeprob = rpm.RPMPROB_DISKNODES

	for (descr, (type, mount, need)) in problems:
            log("(%s, (%s, %s, %s))" %(descr, type, mount, need))
            if mount and mount.startswith(instPath):
		mount = mount[len(instPath):]
            if not mount:
                mount = '/'

	    if type == rpm.RPMPROB_DISKSPACE:
		if spaceneeded.has_key (mount) and spaceneeded[mount] < need:
		    spaceneeded[mount] = need
		else:
		    spaceneeded[mount] = need
	    elif type == nodeprob:
		if nodeneeded.has_key (mount) and nodeneeded[mount] < need:
		    nodeneeded[mount] = need
		else:
		    nodeneeded[mount] = need
	    else:
                if descr is None:
                    descr = "no description"
		log ("WARNING: unhandled problem returned from "
                     "transaction set type %d (%s)",
		     type, descr)

	probs = ""
	if spaceneeded:
	    probs = probs + _("You don't appear to have enough disk space "
                              "to install the packages you've selected. "
                              "You need more space on the following "
                              "file systems:\n\n")
	    probs = probs + ("%-15s %s\n") % (_("Mount Point"),
                                              _("Space Needed"))

	    for (mount, need) in spaceneeded.items ():
                log("(%s, %s)" %(mount, need))
		if need > (1024*1024):
		    need = (need + 1024 * 1024 - 1) / (1024 * 1024)
		    suffix = "M"
		else:
		    need = (need + 1023) / 1024
		    suffix = "k"

		prob = "%-15s %d %c\n" % (mount, need, suffix)
		probs = probs + prob
	if nodeneeded:
	    if probs:
		probs = probs + '\n'
	    probs = probs + _("You don't appear to have enough file nodes "
                              "to install the packages you've selected. "
                              "You need more file nodes on the following "
                              "file systems:\n\n")
	    probs = probs + ("%-15s %s\n") % (_("Mount Point"),
                                              _("Nodes Needed"))

	    for (mount, need) in nodeneeded.items ():
		prob = "%-15s %d\n" % (mount, need)
		probs = probs + prob

        if len(probs) == 0:
            probs = ("ERROR: NO!  An unexpected problem has occurred with "
                     "your transaction set.  Please see tty3 for more "
                     "information")

	intf.messageWindow (_("Disk Space"), probs)

        ts.closeDB()
	del ts
	instLog.close()
	syslog.stop()

	method.systemUnmounted ()

	return DISPATCH_BACK

    # This should close the RPM database so that you can
    # do RPM ops in the chroot in a %post ks script
    ts.closeDB()
    del ts

    # make sure the window gets popped (#82862)
    if not cb.beenCalled:
        cb.initWindow.pop()
    
    method.filesDone ()

    # rpm environment files go bye-bye
    for file in ["__db.001", "__db.002", "__db.003"]:
        try:
            os.unlink("%s/var/lib/rpm/%s" %(instPath, file))
        except Exception, e:
            log("failed to unlink /var/lib/rpm/%s: %s" %(file,e))
    # FIXME: remove the /var/lib/rpm symlink that keeps us from having
    # db->close error messages shown.  I don't really like this though :(
    try:
        os.unlink("/var/lib/rpm")
    except Exception, e:
        log("failed to unlink /var/lib/rpm: %s" %(e,))
            

    if upgrade:
        instLog.write(_("\n\nThe following packages were available in "
                        "this version but NOT upgraded:\n"))
        lines = []
        for p in id.hdList.packages.values ():
            if not p.selected:
                lines.append("%s-%s-%s.%s.rpm\n" %
                             (p.h[rpm.RPMTAG_NAME],
                              p.h[rpm.RPMTAG_VERSION],
                              p.h[rpm.RPMTAG_RELEASE],
                              p.h[rpm.RPMTAG_ARCH]))
        lines.sort()
        for line in lines:
            instLog.write(line)
    instLog.close ()

    id.instProgress = None

def doPostInstall(method, id, intf, instPath):
    if flags.test:
	return
    
    w = intf.progressWindow(_("Post Install"),
                            _("Performing post install configuration..."), 6)

    upgrade = id.upgrade.get()
    arch = iutil.getArch ()

    if upgrade:
	logname = '/root/upgrade.log'
    else:
	logname = '/root/install.log'

    instLogName = instPath + logname
    instLog = open(instLogName, "a")
    
    try:
	if not upgrade:
	    w.set(1)

	    copyExtraModules(instPath, id.comps, id.extraModules)

	    w.set(2)

	    # pcmcia is supported only on i386 at the moment
	    if arch == "i386":
		pcmcia.createPcmciaConfig(
			instPath + "/etc/sysconfig/pcmcia")
		       
	    w.set(3)

	    # blah.  If we're on a serial mouse, and we have X, we need to
	    # close the mouse device, then run kudzu, then open it again.

	    # turn it off
	    mousedev = None

	    # XXX currently Bad Things (X async reply) happen when doing
	    # Mouse Magic on Sparc (Mach64, specificly)
	    # The s390 doesn't even have a mouse!
	    if os.environ.has_key ("DISPLAY") and not (arch == "sparc" or arch == "s390"):
		import xmouse
		try:
		    mousedev = xmouse.get()[0]
		except RuntimeError:
		    pass

	    if mousedev:
		try:
		    os.rename (mousedev, "/dev/disablemouse")
		except OSError:
		    pass
		try:
		    xmouse.reopen()
		except RuntimeError:
		    pass

	    if arch != "s390":
		# we need to unmount usbdevfs before mounting it
		usbWasMounted = iutil.isUSBDevFSMounted()
		if usbWasMounted:
                    isys.umount('/proc/bus/usb', removeDir = 0)

		    # see if unmount suceeded, if not pretent it isnt mounted
		    # because we're screwed anywyas if system is going to
		    # lock up
		    if iutil.isUSBDevFSMounted():
			usbWasMounted = 0
		    
                unmountUSB = 0
                try:
                    isys.mount('/usbdevfs', instPath+'/proc/bus/usb', 'usbdevfs')
                    unmountUSB = 1
                except:
                    log("Mount of /proc/bus/usb in chroot failed")
                    pass

                argv = [ "/usr/sbin/kudzu", "-q" ]
                if id.hdList.has_key("kernel"):
                    ver = "%s-%s" %(id.hdList["kernel"][rpm.RPMTAG_VERSION],
                                    id.hdList["kernel"][rpm.RPMTAG_RELEASE])
                    argv.extend(["-k", ver])
                
                devnull = os.open("/dev/null", os.O_RDWR)
                iutil.execWithRedirect(argv[0], argv, root = instPath,
                                       stdout = devnull)
                # turn it back on            
                if mousedev:
                    try:
                        os.rename ("/dev/disablemouse", mousedev)
                    except OSError:
                        pass
                    try:
                        xmouse.reopen()
                    except RuntimeError:
                        pass

                if unmountUSB:
                    try:
                        isys.umount(instPath + '/proc/bus/usb', removeDir = 0)
                    except SystemError:
                        # if we fail to unmount, then we should just not
                        # try to remount it.  this protects us from random
                        # suckage
                        usbWasMounted = 0

		if usbWasMounted:
                    isys.mount('/usbdevfs', '/proc/bus/usb', 'usbdevfs')

	w.set(4)

        if upgrade and id.dbpath is not None:
            # remove the old rpmdb
	    try:
		iutil.rmrf (id.dbpath)
	    except OSError:
		pass

        if upgrade:
	    # needed for prior systems which were not xinetd based
	    migrateXinetd(instPath, instLogName)

        w.set(5)

        # FIXME: hack to install the comps package
        if (id.compspkg is not None and
            os.access(id.compspkg, os.R_OK)):
            log("found the comps package")
            try:
                # ugly hack
                path = id.compspkg.split("/mnt/sysimage")[1]
                args = ["/bin/rpm", "-Uvh", path]
                rc = iutil.execWithRedirect(args[0], args,
                                            stdout = "/dev/tty5",
                                            stderr = "/dev/tty5",
                                            root = instPath)
                ts = rpm.TransactionSet()
                ts.setVSFlags(~(rpm.RPMVSF_NORSA|rpm.RPMVSF_NODSA))
                ts.closeDB()
                fd = os.open(id.compspkg, os.O_RDONLY)
                h = ts.hdrFromFdno(fd)
                os.close(fd)
                if upgrade:
                    text = _("Upgrading %s-%s-%s.\n")
                else:
                    text = _("Installing %s-%s-%s.\n")
                instLog.write(text % (h['name'],
                                      h['version'],
                                      h['release']))
                os.unlink(id.compspkg)
                del ts

            except Exception, e:
                log("comps.rpm failed to install: %s" %(e,))
                try:
                    os.unlink(id.compspkg)
                except:
                    pass
        else:
            log("no comps package found")
                
        w.set(6)


    finally:
	pass

    # XXX hack - we should really write a proper /etc/lvmtab.  but for now
    # just create the lvmtab if they have /sbin/vgscan and some VGs
    if (os.access(instPath + "/sbin/vgscan", os.X_OK) and
        os.access(instPath + "/proc/lvm", os.R_OK) and
        len(os.listdir("/proc/lvm/VGs")) > 0):
        rc = iutil.execWithRedirect("/sbin/vgscan",
                                    ["vgscan", "-v"],
                                    stdout = "/dev/tty5",
                                    stderr = "/dev/tty5",
                                    root = instPath,
                                    searchPath = 1)

    # write out info on install method used
    try:
	if id.methodstr is not None:
	    if os.access (instPath + "/etc/sysconfig/installinfo", os.R_OK):
		os.rename (instPath + "/etc/sysconfig/installinfo",
			   instPath + "/etc/sysconfig/installinfo.rpmsave")

	    f = open(instPath + "/etc/sysconfig/installinfo", "w+")
	    f.write("INSTALLMETHOD=%s\n" % (string.split(id.methodstr, ':')[0],))

	    try:
		ii = open("/tmp/isoinfo", "r")
		il = ii.readlines()
		ii.close()
		for line in il:
		    f.write(line)
	    except:
		pass
	    f.close()
	else:
	    log("methodstr not set for some reason")
    except:
	log("Failed to write out installinfo")
        
    w.pop ()

    sys.stdout.flush()
    syslog.stop()

def migrateXinetd(instPath, instLog):
    if not os.access (instPath + "/usr/sbin/inetdconvert", os.X_OK):
	return

    if not os.access (instPath + "/etc/inetd.conf.rpmsave", os.R_OK):
	return

    argv = [ "/usr/sbin/inetdconvert", "--convertremaining",
	     "--inetdfile", "/etc/inetd.conf.rpmsave" ]

    logfile = os.open (instLog, os.O_APPEND)
    iutil.execWithRedirect(argv[0], argv, root = instPath,
			   stdout = logfile, stderr = logfile)
    os.close(logfile)

def copyExtraModules(instPath, comps, extraModules):
    kernelVersions = comps.kernelVersionList()

    for (path, subdir, name) in extraModules:
        if not path:
            path = "/modules.cgz"
	pattern = ""
	names = ""
	for (n, tag) in kernelVersions:
	    pattern = pattern + " " + n + "/" + name + ".o"
	    names = names + " " + name + ".o"
	command = ("cd %s/lib/modules; gunzip < %s | "
                   "%s/bin/cpio  --quiet -iumd %s" % 
                   (instPath, path, instPath, pattern))
	log("running: '%s'" % (command, ))
	os.system(command)

	for (n, tag) in kernelVersions:
	    fromFile = "%s/lib/modules/%s/%s.o" % (instPath, n, name)
	    toDir = "%s/lib/modules/%s/kernel/drivers/%s" % \
		    (instPath, n, subdir)
	    to = "%s/%s.o" % (toDir, name)

	    if (os.access(fromFile, os.R_OK) and 
		    os.access(toDir, os.X_OK)):
		log("moving %s to %s" % (fromFile, to))
		os.rename(fromFile, to)

		# the file might not have been owned by root in the cgz
		os.chown(to, 0, 0)
	    else:
		log("missing DD module %s (this may be okay)" % 
			    fromFile)

            recreateInitrd(n, instPath)


#Recreate initrd for use when driver disks add modules
def recreateInitrd (kernelTag, instRoot):
    log("recreating initrd for %s" % (kernelTag,))
    if iutil.getArch() == 'ia64':
        initrd = "/boot/efi/EFI/redhat/initrd-%s.img" % (kernelTag, )
    else:
        initrd = "/boot/initrd-%s.img" % (kernelTag, )

    iutil.execWithRedirect("/sbin/mkinitrd",
                           [ "/sbin/mkinitrd", "--ifneeded", "-f",
                             initrd, kernelTag ],
                           stdout = None, stderr = None,
                           searchPath = 1, root = instRoot)
                

# XXX Deprecated.  Is this ever called anymore?
def depmodModules(comps, instPath):
    kernelVersions = comps.kernelVersionList()

    for (version, tag) in kernelVersions:
	iutil.execWithRedirect ("/sbin/depmod",
				[ "/sbin/depmod", "-a", version,
                                  "-F", "/boot/System.map-" + version ],
				root = instPath, stderr = '/dev/null')


def betaNagScreen(intf, dir):
    if dir == DISPATCH_BACK:
	return DISPATCH_NOOP
    
    while 1:
	rc = intf.messageWindow( _("Warning! This is a beta!"),
				 _("Thank you for downloading this "
				   "%s Beta release.\n\n"
				   "This is not a final "
				   "release and is not intended for use "
				   "on production systems.  The purpose of "
				   "this release is to collect feedback "
				   "from testers, and it is not suitable "
				   "for day to day usage.\n\n"
				   "To report feedback, please visit:\n\n"
				   "   http://bugzilla.redhat.com/bugzilla\n\n"
				   "and file a report against '%s Beta'.\n"
                                   %(productName, productName,)),
				   type="custom", custom_icon="warning",
				   custom_buttons=[_("_Exit"), _("_Install BETA")])

	if not rc:
	    rc = intf.messageWindow( _("Rebooting System"),
				 _("Your system will now be rebooted..."),
				 type="custom", custom_icon="warning",
				 custom_buttons=[_("_Back"), _("_Reboot")])
	    if rc:
		sys.exit(0)
	else:
	    break

# FIXME: this is a kind of poor way to do this, but it will work for now
def selectLanguageSupportGroups(comps, langSupport):
    sup = langSupport.supported
    if len(sup) == 0:
        sup = langSupport.getAllSupported()

    for group in comps.compsxml.groups.values():
        for name in sup:
            try:
                lang = langSupport.langInfoByName[name][0]
                langs = language.expandLangs(lang)
            except:
                continue
            if group.langonly in langs:
                if not comps.compsDict.has_key(group.name):
                    log("Where did the %s component go?"
                        %(group.name,))
                    continue
                comps.compsDict[group.name].select()
                for package in group.pkgConditionals.keys():
                    req = group.pkgConditionals[package]
                    if not comps.packages.has_key(package):
                        log("Missing %s which is in a langsupport conditional" %(package,))
                        continue
                    if not comps.compsxml.packages.has_key(req):
                        log("Missing %s which is required by %s in a langsupport group" %(req, package))
                        continue
                    # add to the deps in the dependencies structure --
                    # this will take care of if we're ever added as a dep
                    comps.compsxml.packages[req].dependencies.append(package)
                    # also add to components as needed
                    # if the req is PKGTYPE_MANDATORY, then just add to the
                    # depsDict.  if the req is PKGTYPE_DEFAULT, add it
                    # as DEFAULT
                    pkg = comps.packages[package]
                    reqp = comps.packages[req]
                    for comp in comps.packages[req].comps:
                        if comp.newpkgDict.has_key(reqp):
                            if comp.newpkgDict[reqp][0] == PKGTYPE_MANDATORY:
                                comp.addDependencyPackage(pkg)
                                comp.updateDependencyCountForAddition(pkg)
                            else:
                                comp.addPackage(pkg, PKGTYPE_DEFAULT)
                        elif comp.depsDict.has_key(req):
                            comp.addDependencyPackage(pkg)
                            comp.updateDependencyCountForAddition(pkg)
    comps.updateSelections()
