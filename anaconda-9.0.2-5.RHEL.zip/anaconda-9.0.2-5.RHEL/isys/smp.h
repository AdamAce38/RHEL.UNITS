#ifndef SMP_H
#define SMP_H

int detectSMP(void);
int detectHT(void);
int detectSummit(void);

#endif /* SMP_H */
